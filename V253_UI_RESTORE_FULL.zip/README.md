# Iron Music 420 AI v2.3.2 — Neon Core UI

Bulgarian Flutter rap assistant with Gemini, Bulgarian voice, local projects and Suno-ready export.

## Ново във v2.3.2

- цялостен черно-зелен неонов интерфейс;
- ново AI ядро със стилизирано 420 листо и HUD анимация;
- футуристичен фон с дискретни waveform, grid и leaf детайли;
- нов начален екран с бързи действия и AI статус;
- нова долна навигация;
- обновени панели, полета, бутони и чат балончета;
- преработена библиотека „Моите песни“ с проектни карти и бързи действия;
- Rap Studio 2.3.2 с по-чиста визуална йерархия;
- запазени всички функции от v2.2: Lyrics, Style of Music, Exclude, Suno пакет, AI редактор, автозапазване, история, български микрофон и глас.

## Build

1. `flutter pub get`
2. `flutter build apk --release`

## Build fix 2.3.2
- Премахнати са Android 12 `values-v31` splash стиловете, които FlutLab не разпознаваше (`postSplashScreenTheme`).
- Използва се стабилният общ тъмен launch theme за всички Android версии.

## v2.4.0 Exact Home UI
Началният екран е преработен максимално близо до одобрения неонов HUD макет: голямо 7-листно ядро, метален надпис, динамичен API статус, четири основни бутона и заоблена долна навигация. Всички работещи функции от v2.3.3 са запазени.


## v2.5.3 Music Mode Fix
Music Mode does not open Spotify or a browser. It broadcasts `music_mode_420` to MacroDroid, and MacroDroid decides which installed app to launch.
